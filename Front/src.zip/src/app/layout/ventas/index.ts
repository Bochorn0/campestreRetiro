export * from './contrato/contrato.component';
export * from './clientes/clientes.component';


