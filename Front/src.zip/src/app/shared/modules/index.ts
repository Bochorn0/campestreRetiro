export * from './page-header/page-header.module';
export * from './stat/stat.module';
export * from './datatables-general/datatables-general.module';
//export * from './catalogo-clientes/catalogo-clientes.module';
export * from './shared.module';